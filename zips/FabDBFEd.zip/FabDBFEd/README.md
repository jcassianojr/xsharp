# FabDBFEd

A DBF Editor, written with X#

Open DBF files : VFP, CDX, NTX  
Memo text Editor based on ICSharpCode.TextEditor  
Simple Create/Modify/View DBF  
Generate Record Model for XSharp


![Screen Shot](https://github.com/FabToys/FabDBFEd/blob/master/FabDBFEd_ScreenShot.jpg)

