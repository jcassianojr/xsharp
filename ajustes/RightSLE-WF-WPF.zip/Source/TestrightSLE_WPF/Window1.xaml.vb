﻿Imports wmGui.wpf
Class Window1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub FocusChecked(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles rbFocusHome.Click, rbFocusAll.Click, rbFocusTrim.Click, rbFocusEnd.Click, rbFocusAuto.Click, rbFocusNumeric.Click, rbFocusRemember.Click
        Select Case CType(sender, RadioButton).Name
            Case "rbFocusHome"
                wmGui.wpf.rightSLE.DefaultSelectionOnFocus = focusBehavior.Home
            Case "rbFocusAll"
                wmGui.wpf.rightSLE.DefaultSelectionOnFocus = focusBehavior.All
            Case "rbFocusAuto"
                wmGui.wpf.rightSLE.DefaultSelectionOnFocus = focusBehavior.Auto
            Case "rbFocusEnd"
                wmGui.wpf.rightSLE.DefaultSelectionOnFocus = focusBehavior.End
            Case "rbFocusTrim"
                wmGui.wpf.rightSLE.DefaultSelectionOnFocus = focusBehavior.Trimmed
            Case "rbFocusNumeric"
                wmGui.wpf.rightSLE.DefaultSelectionOnFocus = focusBehavior.Numeric
            Case "rbFocusRemember"
                wmGui.wpf.rightSLE.DefaultSelectionOnFocus = focusBehavior.RememberLast
        End Select
    End Sub

    Private Sub EnterChecked(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
        Select Case CType(sender, RadioButton).Name
            Case "rbEnterAuto"
                wmGui.wpf.rightSLE.DefaultProcessEnter = KeyHandling.Auto
            Case "rbEnterProcess"
                wmGui.wpf.rightSLE.DefaultProcessEnter = KeyHandling.Process
            Case "rbEnterIgnore"
                wmGui.wpf.rightSLE.DefaultProcessEnter = KeyHandling.Ignore
        End Select
    End Sub
    Private Sub ArrowChecked(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles rbArrowAuto.Click, rbArrowProcess.Click, rbArrowIgnore.Click
        Select Case CType(sender, RadioButton).Name
            Case "rbArrowAuto"
                wmGui.wpf.rightSLE.DefaultProcessArrow = KeyHandling.Auto
            Case "rbArrowProcess"
                wmGui.wpf.rightSLE.DefaultProcessArrow = KeyHandling.Process
            Case "rbArrowIgnore"
                wmGui.wpf.rightSLE.DefaultProcessArrow = KeyHandling.Ignore
        End Select
    End Sub

    Private Sub pbSetPicture_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles pbSetPicture.Click
        Dim cDataType As String

        ' set the datatype based on the combobox
        cDataType = Me.cbType.SelectedItem.Content.ToString()
        Select Case cDataType
            Case "Numeric"
                Me.sleFromPicture.Type = SLEType.Numeric
            Case "Character"
                Me.sleFromPicture.Type = SLEType.Character
            Case "Date"
                Me.sleFromPicture.Type = SLEType.Date
            Case "Logic"
                Me.sleFromPicture.Type = SLEType.Logic
            Case Else
                Me.sleFromPicture.Type = SLEType.Character
        End Select

        ' Set the picture
        Me.sleFromPicture.Picture = Me.slecPicture.Text.Trim()

    End Sub

    Private Sub Grid1_Loaded(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles Grid1.Loaded
        Me.slecPicture.Text = Me.sleFromPicture.Picture

        ' set the combobox based on the Initial SLE value
        Select Case Me.sleFromPicture.Type
            Case SLEType.Numeric
                Me.cbType.Text = "Numeric"
            Case SLEType.Character
                Me.cbType.Text = "Character"
            Case SLEType.Date
                Me.cbType.Text = "Date"
            Case SLEType.Logic
                Me.cbType.Text = "Logic"
            Case Else
                Me.cbType.Text = "Character"
        End Select
        Me.RightSLE1.Focus()
    End Sub
End Class
