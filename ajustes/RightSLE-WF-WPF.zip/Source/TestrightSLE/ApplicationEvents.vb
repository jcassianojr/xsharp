﻿Imports wmGUI
Imports System.Windows.Forms

Friend Class AppMgr
    <STAThread()> _
    Shared Sub main()
        Dim oForm As Form1

        ' ********************************************
        ' * Set up the defaults for all SLEs         *
        ' ********************************************
        wmGUI.rightSLE.DefaultSelectionOnFocus = focusBehavior.All
        wmGUI.rightSLE.DefaultOverwrite = overwriteBehavior.Onkey

        ' *******************************************
        ' * now that we have out SLE defaults       *
        ' * startup the application                 *
        ' *******************************************
        oForm = New Form1()
        Application.Run(oForm)
    End Sub

End Class

