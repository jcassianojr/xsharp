﻿Imports wmGUI
Public Class gen_money
    Inherits PictureSpec
    Sub New()
        MyBase.New(SLEType.Numeric, 12, 2)
        Me.Picture = "9,999,999.99"
    End Sub
End Class
Public Class gen_currency
    Inherits PictureSpec
    Sub New()
        MyBase.New(SLEType.Numeric, 11, 2)
        Me.Picture = "$999,999.99"
    End Sub
End Class