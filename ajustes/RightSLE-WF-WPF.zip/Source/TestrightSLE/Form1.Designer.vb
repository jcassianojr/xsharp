﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pbCloseButton = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.pbStartTimer = New System.Windows.Forms.Button()
        Me.pbStopTimer = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.slenTimer = New wmGUI.timerSLE()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.pbUpdateFS = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.rbRemember = New System.Windows.Forms.RadioButton()
        Me.rbNumeric = New System.Windows.Forms.RadioButton()
        Me.rbAuto = New System.Windows.Forms.RadioButton()
        Me.rbEnd = New System.Windows.Forms.RadioButton()
        Me.rbTrim = New System.Windows.Forms.RadioButton()
        Me.rbAll = New System.Windows.Forms.RadioButton()
        Me.rbHome = New System.Windows.Forms.RadioButton()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.rbEnterAuto = New System.Windows.Forms.RadioButton()
        Me.rbIgnore = New System.Windows.Forms.RadioButton()
        Me.rbProcess = New System.Windows.Forms.RadioButton()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.rbArrowAuto = New System.Windows.Forms.RadioButton()
        Me.rbArrowIgnore = New System.Windows.Forms.RadioButton()
        Me.rbArrowProcess = New System.Windows.Forms.RadioButton()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.pbHide = New System.Windows.Forms.Button()
        Me.pbEnable = New System.Windows.Forms.Button()
        Me.pbFirstDayOfWeek = New System.Windows.Forms.Button()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.pbReadOnly = New System.Windows.Forms.Button()
        Me.PbDateSLE1 = New wmGUI.pbDateSLE()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.cbType = New System.Windows.Forms.ComboBox()
        Me.slecPicture = New wmGUI.rightSLE()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.RightSLE3 = New wmGUI.rightSLE()
        Me.RightSLE1 = New wmGUI.rightSLE()
        Me.PbFileSLE1 = New wmGUI.pbFileSLE()
        Me.PbInlineCalcSLE1 = New wmGUI.pbInlineCalcSLE()
        Me.PbCalcSLE1 = New wmGUI.pbCalcSLE()
        Me.PbSearchSLE1 = New wmGUI.pbSearchSLE()
        Me.PbFolderSLE1 = New wmGUI.pbFolderSLE()
        Me.RightSLE2 = New wmGUI.rightSLE()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.SuspendLayout()
        '
        'pbCloseButton
        '
        Me.pbCloseButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.pbCloseButton.Location = New System.Drawing.Point(435, 395)
        Me.pbCloseButton.Name = "pbCloseButton"
        Me.pbCloseButton.Size = New System.Drawing.Size(75, 23)
        Me.pbCloseButton.TabIndex = 21
        Me.pbCloseButton.Text = "&Close"
        Me.pbCloseButton.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(17, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(50, 13)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "DateSLE"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(33, 308)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(74, 13)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Phone Picture"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 79)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(66, 13)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "NumericSLE"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'pbStartTimer
        '
        Me.pbStartTimer.Location = New System.Drawing.Point(18, 51)
        Me.pbStartTimer.Name = "pbStartTimer"
        Me.pbStartTimer.Size = New System.Drawing.Size(63, 26)
        Me.pbStartTimer.TabIndex = 19
        Me.pbStartTimer.Text = "Start"
        Me.pbStartTimer.UseVisualStyleBackColor = True
        '
        'pbStopTimer
        '
        Me.pbStopTimer.Location = New System.Drawing.Point(87, 51)
        Me.pbStopTimer.Name = "pbStopTimer"
        Me.pbStopTimer.Size = New System.Drawing.Size(66, 26)
        Me.pbStopTimer.TabIndex = 20
        Me.pbStopTimer.Text = "Stop"
        Me.pbStopTimer.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.pbStartTimer)
        Me.GroupBox1.Controls.Add(Me.pbStopTimer)
        Me.GroupBox1.Controls.Add(Me.slenTimer)
        Me.GroupBox1.Location = New System.Drawing.Point(357, 248)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(189, 85)
        Me.GroupBox1.TabIndex = 20
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Timer"
        '
        'slenTimer
        '
        Me.slenTimer.__CurPos = 1
        Me.slenTimer.AutoFocusChange = False
        Me.slenTimer.CustomBitmapHandling = wmGUI.ImageHandling.[Auto]
        Me.slenTimer.FieldSpec = Nothing
        Me.slenTimer.Location = New System.Drawing.Point(18, 19)
        Me.slenTimer.Name = "slenTimer"
        Me.slenTimer.Overwrite = wmGUI.overwriteBehavior.[Auto]
        Me.slenTimer.Owner = Nothing
        Me.slenTimer.Picture = Nothing
        Me.slenTimer.ProcessArrow = wmGUI.KeyHandling.[Auto]
        Me.slenTimer.ProcessEnter = wmGUI.KeyHandling.[Auto]
        Me.slenTimer.ReadOnly = True
        Me.slenTimer.scrlMode = wmGUI.scrlModeBehavior.Full
        Me.slenTimer.selectionOnFocus = wmGUI.focusBehavior.[Auto]
        Me.slenTimer.Size = New System.Drawing.Size(135, 20)
        Me.slenTimer.TabIndex = 18
        Me.slenTimer.TabStop = False
        Me.slenTimer.Type = wmGUI.SLEType.[Auto]
        Me.slenTimer.zSetButton = wmGUI.KeyHandling.[Auto]
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(358, 56)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(52, 13)
        Me.Label5.TabIndex = 18
        Me.Label5.Text = "File Open"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(333, 94)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(77, 13)
        Me.Label6.TabIndex = 20
        Me.Label6.Text = "Folder Browser"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'pbUpdateFS
        '
        Me.pbUpdateFS.Location = New System.Drawing.Point(190, 44)
        Me.pbUpdateFS.Name = "pbUpdateFS"
        Me.pbUpdateFS.Size = New System.Drawing.Size(68, 23)
        Me.pbUpdateFS.TabIndex = 8
        Me.pbUpdateFS.Text = "Update FS"
        Me.pbUpdateFS.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(342, 135)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(59, 13)
        Me.Label7.TabIndex = 26
        Me.Label7.Text = "searchSLE"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(354, 174)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(47, 13)
        Me.Label8.TabIndex = 30
        Me.Label8.Text = "calcSLE"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(327, 209)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(74, 13)
        Me.Label9.TabIndex = 31
        Me.Label9.Text = "inline calcSLE"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.rbRemember)
        Me.GroupBox2.Controls.Add(Me.rbNumeric)
        Me.GroupBox2.Controls.Add(Me.rbAuto)
        Me.GroupBox2.Controls.Add(Me.rbEnd)
        Me.GroupBox2.Controls.Add(Me.rbTrim)
        Me.GroupBox2.Controls.Add(Me.rbAll)
        Me.GroupBox2.Controls.Add(Me.rbHome)
        Me.GroupBox2.Location = New System.Drawing.Point(570, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(164, 188)
        Me.GroupBox2.TabIndex = 22
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Default Focus Selection"
        '
        'rbRemember
        '
        Me.rbRemember.AutoSize = True
        Me.rbRemember.Location = New System.Drawing.Point(27, 156)
        Me.rbRemember.Name = "rbRemember"
        Me.rbRemember.Size = New System.Drawing.Size(99, 17)
        Me.rbRemember.TabIndex = 6
        Me.rbRemember.TabStop = True
        Me.rbRemember.Text = "Remember Last"
        Me.rbRemember.UseVisualStyleBackColor = True
        '
        'rbNumeric
        '
        Me.rbNumeric.AutoSize = True
        Me.rbNumeric.Location = New System.Drawing.Point(27, 133)
        Me.rbNumeric.Name = "rbNumeric"
        Me.rbNumeric.Size = New System.Drawing.Size(64, 17)
        Me.rbNumeric.TabIndex = 5
        Me.rbNumeric.TabStop = True
        Me.rbNumeric.Text = "Numeric"
        Me.rbNumeric.UseVisualStyleBackColor = True
        '
        'rbAuto
        '
        Me.rbAuto.AutoSize = True
        Me.rbAuto.Location = New System.Drawing.Point(27, 110)
        Me.rbAuto.Name = "rbAuto"
        Me.rbAuto.Size = New System.Drawing.Size(47, 17)
        Me.rbAuto.TabIndex = 4
        Me.rbAuto.TabStop = True
        Me.rbAuto.Text = "Auto"
        Me.rbAuto.UseVisualStyleBackColor = True
        '
        'rbEnd
        '
        Me.rbEnd.AutoSize = True
        Me.rbEnd.Location = New System.Drawing.Point(27, 90)
        Me.rbEnd.Name = "rbEnd"
        Me.rbEnd.Size = New System.Drawing.Size(44, 17)
        Me.rbEnd.TabIndex = 3
        Me.rbEnd.TabStop = True
        Me.rbEnd.Text = "End"
        Me.rbEnd.UseVisualStyleBackColor = True
        '
        'rbTrim
        '
        Me.rbTrim.AutoSize = True
        Me.rbTrim.Location = New System.Drawing.Point(27, 66)
        Me.rbTrim.Name = "rbTrim"
        Me.rbTrim.Size = New System.Drawing.Size(45, 17)
        Me.rbTrim.TabIndex = 2
        Me.rbTrim.TabStop = True
        Me.rbTrim.Text = "Trim"
        Me.rbTrim.UseVisualStyleBackColor = True
        '
        'rbAll
        '
        Me.rbAll.AutoSize = True
        Me.rbAll.Location = New System.Drawing.Point(27, 42)
        Me.rbAll.Name = "rbAll"
        Me.rbAll.Size = New System.Drawing.Size(36, 17)
        Me.rbAll.TabIndex = 1
        Me.rbAll.TabStop = True
        Me.rbAll.Text = "All"
        Me.rbAll.UseVisualStyleBackColor = True
        '
        'rbHome
        '
        Me.rbHome.AutoSize = True
        Me.rbHome.Location = New System.Drawing.Point(27, 20)
        Me.rbHome.Name = "rbHome"
        Me.rbHome.Size = New System.Drawing.Size(53, 17)
        Me.rbHome.TabIndex = 0
        Me.rbHome.TabStop = True
        Me.rbHome.Text = "Home"
        Me.rbHome.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.rbEnterAuto)
        Me.GroupBox3.Controls.Add(Me.rbIgnore)
        Me.GroupBox3.Controls.Add(Me.rbProcess)
        Me.GroupBox3.Location = New System.Drawing.Point(570, 206)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(164, 100)
        Me.GroupBox3.TabIndex = 23
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Default Enter Key"
        '
        'rbEnterAuto
        '
        Me.rbEnterAuto.AutoSize = True
        Me.rbEnterAuto.Location = New System.Drawing.Point(16, 66)
        Me.rbEnterAuto.Name = "rbEnterAuto"
        Me.rbEnterAuto.Size = New System.Drawing.Size(47, 17)
        Me.rbEnterAuto.TabIndex = 2
        Me.rbEnterAuto.TabStop = True
        Me.rbEnterAuto.Text = "Auto"
        Me.rbEnterAuto.UseVisualStyleBackColor = True
        '
        'rbIgnore
        '
        Me.rbIgnore.AutoSize = True
        Me.rbIgnore.Location = New System.Drawing.Point(16, 42)
        Me.rbIgnore.Name = "rbIgnore"
        Me.rbIgnore.Size = New System.Drawing.Size(55, 17)
        Me.rbIgnore.TabIndex = 1
        Me.rbIgnore.TabStop = True
        Me.rbIgnore.Text = "Ignore"
        Me.rbIgnore.UseVisualStyleBackColor = True
        '
        'rbProcess
        '
        Me.rbProcess.AutoSize = True
        Me.rbProcess.Location = New System.Drawing.Point(16, 18)
        Me.rbProcess.Name = "rbProcess"
        Me.rbProcess.Size = New System.Drawing.Size(63, 17)
        Me.rbProcess.TabIndex = 0
        Me.rbProcess.TabStop = True
        Me.rbProcess.Text = "Process"
        Me.rbProcess.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.rbArrowAuto)
        Me.GroupBox4.Controls.Add(Me.rbArrowIgnore)
        Me.GroupBox4.Controls.Add(Me.rbArrowProcess)
        Me.GroupBox4.Location = New System.Drawing.Point(570, 318)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(164, 100)
        Me.GroupBox4.TabIndex = 24
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Default Up/Down Arrows"
        '
        'rbArrowAuto
        '
        Me.rbArrowAuto.AutoSize = True
        Me.rbArrowAuto.Location = New System.Drawing.Point(16, 66)
        Me.rbArrowAuto.Name = "rbArrowAuto"
        Me.rbArrowAuto.Size = New System.Drawing.Size(47, 17)
        Me.rbArrowAuto.TabIndex = 2
        Me.rbArrowAuto.TabStop = True
        Me.rbArrowAuto.Text = "Auto"
        Me.rbArrowAuto.UseVisualStyleBackColor = True
        '
        'rbArrowIgnore
        '
        Me.rbArrowIgnore.AutoSize = True
        Me.rbArrowIgnore.Location = New System.Drawing.Point(16, 42)
        Me.rbArrowIgnore.Name = "rbArrowIgnore"
        Me.rbArrowIgnore.Size = New System.Drawing.Size(55, 17)
        Me.rbArrowIgnore.TabIndex = 1
        Me.rbArrowIgnore.TabStop = True
        Me.rbArrowIgnore.Text = "Ignore"
        Me.rbArrowIgnore.UseVisualStyleBackColor = True
        '
        'rbArrowProcess
        '
        Me.rbArrowProcess.AutoSize = True
        Me.rbArrowProcess.Location = New System.Drawing.Point(16, 18)
        Me.rbArrowProcess.Name = "rbArrowProcess"
        Me.rbArrowProcess.Size = New System.Drawing.Size(63, 17)
        Me.rbArrowProcess.TabIndex = 0
        Me.rbArrowProcess.TabStop = True
        Me.rbArrowProcess.Text = "Process"
        Me.rbArrowProcess.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(38, 277)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(69, 13)
        Me.Label10.TabIndex = 36
        Me.Label10.Text = "CurrencySLE"
        '
        'pbHide
        '
        Me.pbHide.Location = New System.Drawing.Point(115, 93)
        Me.pbHide.Name = "pbHide"
        Me.pbHide.Size = New System.Drawing.Size(75, 23)
        Me.pbHide.TabIndex = 5
        Me.pbHide.Text = "Hide"
        Me.pbHide.UseVisualStyleBackColor = True
        '
        'pbEnable
        '
        Me.pbEnable.Location = New System.Drawing.Point(20, 58)
        Me.pbEnable.Name = "pbEnable"
        Me.pbEnable.Size = New System.Drawing.Size(75, 23)
        Me.pbEnable.TabIndex = 2
        Me.pbEnable.Text = "Disable"
        Me.pbEnable.UseVisualStyleBackColor = True
        '
        'pbFirstDayOfWeek
        '
        Me.pbFirstDayOfWeek.Location = New System.Drawing.Point(115, 58)
        Me.pbFirstDayOfWeek.Name = "pbFirstDayOfWeek"
        Me.pbFirstDayOfWeek.Size = New System.Drawing.Size(75, 23)
        Me.pbFirstDayOfWeek.TabIndex = 3
        Me.pbFirstDayOfWeek.Text = "Sunday"
        Me.pbFirstDayOfWeek.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.pbReadOnly)
        Me.GroupBox5.Controls.Add(Me.PbDateSLE1)
        Me.GroupBox5.Controls.Add(Me.pbHide)
        Me.GroupBox5.Controls.Add(Me.pbFirstDayOfWeek)
        Me.GroupBox5.Controls.Add(Me.Label1)
        Me.GroupBox5.Controls.Add(Me.pbEnable)
        Me.GroupBox5.Location = New System.Drawing.Point(31, 12)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(210, 128)
        Me.GroupBox5.TabIndex = 1
        Me.GroupBox5.TabStop = False
        '
        'pbReadOnly
        '
        Me.pbReadOnly.Location = New System.Drawing.Point(20, 93)
        Me.pbReadOnly.Name = "pbReadOnly"
        Me.pbReadOnly.Size = New System.Drawing.Size(75, 23)
        Me.pbReadOnly.TabIndex = 4
        Me.pbReadOnly.Text = "ReadOnly"
        Me.pbReadOnly.UseVisualStyleBackColor = True
        '
        'PbDateSLE1
        '
        Me.PbDateSLE1.__CurPos = 1
        Me.PbDateSLE1.AlignCalendarLeft = True
        Me.PbDateSLE1.AutoFocusChange = False
        Me.PbDateSLE1.CalendarMode = wmGUI.CalendarDoubleClickBehavior.Calendar
        Me.PbDateSLE1.CustomBitmapHandling = wmGUI.ImageHandling.[Auto]
        Me.PbDateSLE1.DateRange = Nothing
        Me.PbDateSLE1.FieldSpec = "dateFS"
        Me.PbDateSLE1.FirstDayoftheWeek = CType(99UI, UInteger)
        Me.PbDateSLE1.Holiday = Nothing
        Me.PbDateSLE1.Location = New System.Drawing.Point(90, 23)
        Me.PbDateSLE1.Name = "PbDateSLE1"
        Me.PbDateSLE1.Overwrite = wmGUI.overwriteBehavior.[Auto]
        Me.PbDateSLE1.Owner = Nothing
        Me.PbDateSLE1.Picture = Nothing
        Me.PbDateSLE1.ProcessArrow = wmGUI.KeyHandling.[Auto]
        Me.PbDateSLE1.ProcessEnter = wmGUI.KeyHandling.[Auto]
        Me.PbDateSLE1.scrlMode = wmGUI.scrlModeBehavior.Full
        Me.PbDateSLE1.selectionOnFocus = wmGUI.focusBehavior.[Auto]
        Me.PbDateSLE1.Size = New System.Drawing.Size(100, 20)
        Me.PbDateSLE1.TabIndex = 1
        Me.PbDateSLE1.Type = wmGUI.SLEType.[Auto]
        Me.PbDateSLE1.zSetButton = wmGUI.KeyHandling.[Auto]
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.cbType)
        Me.GroupBox6.Controls.Add(Me.slecPicture)
        Me.GroupBox6.Controls.Add(Me.Label11)
        Me.GroupBox6.Controls.Add(Me.RightSLE3)
        Me.GroupBox6.Controls.Add(Me.pbUpdateFS)
        Me.GroupBox6.Controls.Add(Me.Label3)
        Me.GroupBox6.Location = New System.Drawing.Point(31, 146)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(264, 107)
        Me.GroupBox6.TabIndex = 2
        Me.GroupBox6.TabStop = False
        '
        'cbType
        '
        Me.cbType.FormattingEnabled = True
        Me.cbType.Items.AddRange(New Object() {"Numeric", "Character", "Date", "Logic"})
        Me.cbType.Location = New System.Drawing.Point(80, 46)
        Me.cbType.Name = "cbType"
        Me.cbType.Size = New System.Drawing.Size(100, 21)
        Me.cbType.TabIndex = 7
        '
        'slecPicture
        '
        Me.slecPicture.__CurPos = 1
        Me.slecPicture.AutoFocusChange = False
        Me.slecPicture.CustomBitmapHandling = wmGUI.ImageHandling.[Auto]
        Me.slecPicture.FieldSpec = Nothing
        Me.slecPicture.Location = New System.Drawing.Point(80, 15)
        Me.slecPicture.Name = "slecPicture"
        Me.slecPicture.Overwrite = wmGUI.overwriteBehavior.[Auto]
        Me.slecPicture.Owner = Nothing
        Me.slecPicture.Picture = Nothing
        Me.slecPicture.ProcessArrow = wmGUI.KeyHandling.[Auto]
        Me.slecPicture.ProcessEnter = wmGUI.KeyHandling.[Auto]
        Me.slecPicture.scrlMode = wmGUI.scrlModeBehavior.Full
        Me.slecPicture.selectionOnFocus = wmGUI.focusBehavior.[Auto]
        Me.slecPicture.Size = New System.Drawing.Size(168, 20)
        Me.slecPicture.TabIndex = 6
        Me.slecPicture.Type = wmGUI.SLEType.[Auto]
        Me.slecPicture.zSetButton = wmGUI.KeyHandling.[Auto]
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(22, 18)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(40, 13)
        Me.Label11.TabIndex = 25
        Me.Label11.Text = "Picture"
        '
        'RightSLE3
        '
        Me.RightSLE3.__CurPos = 1
        Me.RightSLE3.AutoFocusChange = False
        Me.RightSLE3.CustomBitmapHandling = wmGUI.ImageHandling.[Auto]
        Me.RightSLE3.FieldSpec = "gen_money"
        Me.RightSLE3.Location = New System.Drawing.Point(80, 76)
        Me.RightSLE3.Name = "RightSLE3"
        Me.RightSLE3.Overwrite = wmGUI.overwriteBehavior.[Auto]
        Me.RightSLE3.Owner = Nothing
        Me.RightSLE3.Picture = ""
        Me.RightSLE3.ProcessArrow = wmGUI.KeyHandling.[Auto]
        Me.RightSLE3.ProcessEnter = wmGUI.KeyHandling.[Auto]
        Me.RightSLE3.scrlMode = wmGUI.scrlModeBehavior.Full
        Me.RightSLE3.selectionOnFocus = wmGUI.focusBehavior.[Auto]
        Me.RightSLE3.Size = New System.Drawing.Size(100, 20)
        Me.RightSLE3.TabIndex = 9
        Me.RightSLE3.Type = wmGUI.SLEType.Numeric
        Me.RightSLE3.zSetButton = wmGUI.KeyHandling.[Auto]
        '
        'RightSLE1
        '
        Me.RightSLE1.__CurPos = 1
        Me.RightSLE1.AutoFocusChange = False
        Me.RightSLE1.CustomBitmapHandling = wmGUI.ImageHandling.[Auto]
        Me.RightSLE1.FieldSpec = Nothing
        Me.RightSLE1.Location = New System.Drawing.Point(121, 270)
        Me.RightSLE1.Name = "RightSLE1"
        Me.RightSLE1.Overwrite = wmGUI.overwriteBehavior.[Auto]
        Me.RightSLE1.Owner = Nothing
        Me.RightSLE1.Picture = ""
        Me.RightSLE1.ProcessArrow = wmGUI.KeyHandling.[Auto]
        Me.RightSLE1.ProcessEnter = wmGUI.KeyHandling.[Auto]
        Me.RightSLE1.scrlMode = wmGUI.scrlModeBehavior.Full
        Me.RightSLE1.selectionOnFocus = wmGUI.focusBehavior.[Auto]
        Me.RightSLE1.Size = New System.Drawing.Size(100, 20)
        Me.RightSLE1.TabIndex = 10
        Me.RightSLE1.Type = wmGUI.SLEType.[Auto]
        Me.RightSLE1.zSetButton = wmGUI.KeyHandling.[Auto]
        '
        'PbFileSLE1
        '
        Me.PbFileSLE1.__CurPos = 1
        Me.PbFileSLE1.AutoFocusChange = False
        Me.PbFileSLE1.CustomBitmapHandling = wmGUI.ImageHandling.[Auto]
        Me.PbFileSLE1.DialogType = wmGUI.FileType.OpenDialog
        Me.PbFileSLE1.FieldSpec = Nothing
        Me.PbFileSLE1.Location = New System.Drawing.Point(416, 49)
        Me.PbFileSLE1.Name = "PbFileSLE1"
        Me.PbFileSLE1.Overwrite = wmGUI.overwriteBehavior.[Auto]
        Me.PbFileSLE1.Owner = Nothing
        Me.PbFileSLE1.Picture = Nothing
        Me.PbFileSLE1.ProcessArrow = wmGUI.KeyHandling.[Auto]
        Me.PbFileSLE1.ProcessEnter = wmGUI.KeyHandling.[Auto]
        Me.PbFileSLE1.scrlMode = wmGUI.scrlModeBehavior.Full
        Me.PbFileSLE1.selectionOnFocus = wmGUI.focusBehavior.[Auto]
        Me.PbFileSLE1.Size = New System.Drawing.Size(130, 20)
        Me.PbFileSLE1.TabIndex = 13
        Me.PbFileSLE1.Type = wmGUI.SLEType.[Auto]
        Me.PbFileSLE1.zSetButton = wmGUI.KeyHandling.[Auto]
        '
        'PbInlineCalcSLE1
        '
        Me.PbInlineCalcSLE1.__CurPos = 1
        Me.PbInlineCalcSLE1.AutoFocusChange = False
        Me.PbInlineCalcSLE1.CustomBitmapHandling = wmGUI.ImageHandling.[Auto]
        Me.PbInlineCalcSLE1.FieldSpec = "gen_money"
        Me.PbInlineCalcSLE1.Location = New System.Drawing.Point(416, 206)
        Me.PbInlineCalcSLE1.Name = "PbInlineCalcSLE1"
        Me.PbInlineCalcSLE1.Overwrite = wmGUI.overwriteBehavior.[Auto]
        Me.PbInlineCalcSLE1.Owner = Nothing
        Me.PbInlineCalcSLE1.Picture = Nothing
        Me.PbInlineCalcSLE1.ProcessArrow = wmGUI.KeyHandling.[Auto]
        Me.PbInlineCalcSLE1.ProcessEnter = wmGUI.KeyHandling.[Auto]
        Me.PbInlineCalcSLE1.scrlMode = wmGUI.scrlModeBehavior.Full
        Me.PbInlineCalcSLE1.selectionOnFocus = wmGUI.focusBehavior.[Auto]
        Me.PbInlineCalcSLE1.Size = New System.Drawing.Size(130, 20)
        Me.PbInlineCalcSLE1.TabIndex = 17
        Me.PbInlineCalcSLE1.Type = wmGUI.SLEType.[Auto]
        Me.PbInlineCalcSLE1.zSetButton = wmGUI.KeyHandling.[Auto]
        '
        'PbCalcSLE1
        '
        Me.PbCalcSLE1.__CurPos = 1
        Me.PbCalcSLE1.AutoFocusChange = False
        Me.PbCalcSLE1.CustomBitmapHandling = wmGUI.ImageHandling.[Auto]
        Me.PbCalcSLE1.FieldSpec = Nothing
        Me.PbCalcSLE1.Location = New System.Drawing.Point(416, 167)
        Me.PbCalcSLE1.Name = "PbCalcSLE1"
        Me.PbCalcSLE1.Overwrite = wmGUI.overwriteBehavior.[Auto]
        Me.PbCalcSLE1.Owner = Nothing
        Me.PbCalcSLE1.Picture = Nothing
        Me.PbCalcSLE1.ProcessArrow = wmGUI.KeyHandling.[Auto]
        Me.PbCalcSLE1.ProcessEnter = wmGUI.KeyHandling.[Auto]
        Me.PbCalcSLE1.scrlMode = wmGUI.scrlModeBehavior.Full
        Me.PbCalcSLE1.selectionOnFocus = wmGUI.focusBehavior.[Auto]
        Me.PbCalcSLE1.Size = New System.Drawing.Size(130, 20)
        Me.PbCalcSLE1.TabIndex = 16
        Me.PbCalcSLE1.Type = wmGUI.SLEType.[Auto]
        Me.PbCalcSLE1.zSetButton = wmGUI.KeyHandling.[Auto]
        '
        'PbSearchSLE1
        '
        Me.PbSearchSLE1.__CurPos = 1
        Me.PbSearchSLE1.AutoFocusChange = False
        Me.PbSearchSLE1.CustomBitmapHandling = wmGUI.ImageHandling.[Auto]
        Me.PbSearchSLE1.FieldSpec = Nothing
        Me.PbSearchSLE1.Location = New System.Drawing.Point(416, 132)
        Me.PbSearchSLE1.Name = "PbSearchSLE1"
        Me.PbSearchSLE1.Overwrite = wmGUI.overwriteBehavior.[Auto]
        Me.PbSearchSLE1.Owner = Nothing
        Me.PbSearchSLE1.Picture = Nothing
        Me.PbSearchSLE1.ProcessArrow = wmGUI.KeyHandling.[Auto]
        Me.PbSearchSLE1.ProcessEnter = wmGUI.KeyHandling.[Auto]
        Me.PbSearchSLE1.scrlMode = wmGUI.scrlModeBehavior.Full
        Me.PbSearchSLE1.selectionOnFocus = wmGUI.focusBehavior.[Auto]
        Me.PbSearchSLE1.Size = New System.Drawing.Size(130, 20)
        Me.PbSearchSLE1.TabIndex = 15
        Me.PbSearchSLE1.Type = wmGUI.SLEType.[Auto]
        Me.PbSearchSLE1.zSetButton = wmGUI.KeyHandling.[Auto]
        '
        'PbFolderSLE1
        '
        Me.PbFolderSLE1.__CurPos = 1
        Me.PbFolderSLE1.AutoFocusChange = False
        Me.PbFolderSLE1.CustomBitmapHandling = wmGUI.ImageHandling.[Auto]
        Me.PbFolderSLE1.FieldSpec = Nothing
        Me.PbFolderSLE1.Location = New System.Drawing.Point(416, 90)
        Me.PbFolderSLE1.Name = "PbFolderSLE1"
        Me.PbFolderSLE1.Overwrite = wmGUI.overwriteBehavior.[Auto]
        Me.PbFolderSLE1.Owner = Nothing
        Me.PbFolderSLE1.Picture = Nothing
        Me.PbFolderSLE1.ProcessArrow = wmGUI.KeyHandling.[Auto]
        Me.PbFolderSLE1.ProcessEnter = wmGUI.KeyHandling.[Auto]
        Me.PbFolderSLE1.scrlMode = wmGUI.scrlModeBehavior.Full
        Me.PbFolderSLE1.selectionOnFocus = wmGUI.focusBehavior.[Auto]
        Me.PbFolderSLE1.Size = New System.Drawing.Size(130, 20)
        Me.PbFolderSLE1.TabIndex = 14
        Me.PbFolderSLE1.Type = wmGUI.SLEType.[Auto]
        Me.PbFolderSLE1.zSetButton = wmGUI.KeyHandling.[Auto]
        '
        'RightSLE2
        '
        Me.RightSLE2.__CurPos = 1
        Me.RightSLE2.AutoFocusChange = False
        Me.RightSLE2.CustomBitmapHandling = wmGUI.ImageHandling.[Auto]
        Me.RightSLE2.FieldSpec = Nothing
        Me.RightSLE2.Location = New System.Drawing.Point(121, 305)
        Me.RightSLE2.Name = "RightSLE2"
        Me.RightSLE2.Overwrite = wmGUI.overwriteBehavior.[Auto]
        Me.RightSLE2.Owner = Nothing
        Me.RightSLE2.Picture = "@R (999) 999-9999"
        Me.RightSLE2.ProcessArrow = wmGUI.KeyHandling.[Auto]
        Me.RightSLE2.ProcessEnter = wmGUI.KeyHandling.[Auto]
        Me.RightSLE2.scrlMode = wmGUI.scrlModeBehavior.Full
        Me.RightSLE2.selectionOnFocus = wmGUI.focusBehavior.[Auto]
        Me.RightSLE2.Size = New System.Drawing.Size(100, 20)
        Me.RightSLE2.TabIndex = 11
        Me.RightSLE2.Type = wmGUI.SLEType.[Auto]
        Me.RightSLE2.zSetButton = wmGUI.KeyHandling.[Auto]
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(60, 395)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(151, 23)
        Me.Button1.TabIndex = 37
        Me.Button1.Text = "Check Empty on FileSLE"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(746, 441)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.RightSLE1)
        Me.Controls.Add(Me.PbFileSLE1)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.PbInlineCalcSLE1)
        Me.Controls.Add(Me.PbCalcSLE1)
        Me.Controls.Add(Me.PbSearchSLE1)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.PbFolderSLE1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.RightSLE2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.pbCloseButton)
        Me.Name = "Form1"
        Me.Text = "Test rightSLE"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pbCloseButton As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents RightSLE3 As wmGUI.rightSLE
    Friend WithEvents pbStartTimer As System.Windows.Forms.Button
    Friend WithEvents slenTimer As wmGUI.timerSLE
    Friend WithEvents pbStopTimer As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents PbDateSLE1 As wmGUI.pbDateSLE
    Friend WithEvents RightSLE2 As wmGUI.rightSLE
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents PbFileSLE1 As wmGUI.pbFileSLE
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents PbFolderSLE1 As wmGUI.pbFolderSLE
    Friend WithEvents pbUpdateFS As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents PbSearchSLE1 As wmGUI.pbSearchSLE
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents PbInlineCalcSLE1 As wmGUI.pbInlineCalcSLE
    Friend WithEvents PbCalcSLE1 As wmGUI.pbCalcSLE
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents rbEnd As System.Windows.Forms.RadioButton
    Friend WithEvents rbTrim As System.Windows.Forms.RadioButton
    Friend WithEvents rbAll As System.Windows.Forms.RadioButton
    Friend WithEvents rbHome As System.Windows.Forms.RadioButton
    Friend WithEvents rbAuto As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents rbEnterAuto As System.Windows.Forms.RadioButton
    Friend WithEvents rbIgnore As System.Windows.Forms.RadioButton
    Friend WithEvents rbProcess As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents rbArrowAuto As System.Windows.Forms.RadioButton
    Friend WithEvents rbArrowIgnore As System.Windows.Forms.RadioButton
    Friend WithEvents rbArrowProcess As System.Windows.Forms.RadioButton
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents RightSLE1 As wmGUI.rightSLE
    Friend WithEvents rbRemember As System.Windows.Forms.RadioButton
    Friend WithEvents rbNumeric As System.Windows.Forms.RadioButton
    Friend WithEvents pbHide As System.Windows.Forms.Button
    Friend WithEvents pbEnable As System.Windows.Forms.Button
    Friend WithEvents pbFirstDayOfWeek As System.Windows.Forms.Button
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents pbReadOnly As System.Windows.Forms.Button
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents slecPicture As wmGUI.rightSLE
    Friend WithEvents cbType As System.Windows.Forms.ComboBox
    Friend WithEvents Button1 As System.Windows.Forms.Button

End Class
