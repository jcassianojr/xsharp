﻿Imports wmGUI
Imports System.Globalization
Imports System.Windows.Forms

Public Class Form1
    Friend rbgFocus As String
    Friend rbgEnter As String
    Friend rbgArrow As String

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pbCloseButton.Click
        MessageBox.Show("ZeroPad is : " & RightSLE3.ZeroPad)
        MessageBox.Show("Phone is :" & RightSLE2.Text)
        ' MessageBox.Show("value is: " & RightSLE2.Value)
        Close()
    End Sub

    Private Sub pbStartTimer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pbStartTimer.Click
        Me.slenTimer.Start()
    End Sub

    Private Sub pbStopTimer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pbStopTimer.Click
        Me.slenTimer.Stop()
    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim aHolidays As New ArrayList
        Dim oDays As wmGUI.Days
        'Dim oDateRange As wmDateRange
        'Dim currentculture As CultureInfo
        'Dim numberformat As NumberFormatInfo

        Try
            wmGUI.rightSLE.DefaultProcessEnter = KeyHandling.Ignore

            'numberformat = NumberFormatInfo.CurrentInfo
            'MessageBox.Show("Culture IS: " & CultureInfo.CurrentCulture.Name & vbCrLf & _
            '              "Decimal Seperator is:" & numberformat.NumberDecimalSeparator & vbCrLf & _
            '               "Thousand Seperator is:" & numberformat.NumberGroupSeparator)

            ' set up the default focus change handling
            Me.rbgFocus = "A"
            Me.rbAll.Checked = True

            ' set up the EnterKey handling
            Me.rbgEnter = "P"
            Me.rbProcess.Checked = True

            ' set up the default arrow handling
            Me.rbgArrow = "P"
            Me.rbArrowProcess.Checked = True

            ' manually set a fieldspec
            ' Me.PbDateSLE1.FieldSpec = "dateFS"
            ' Me.PbDateSLE1.Picture = "@D"
            Me.RightSLE1.FieldSpec = "gen_currency"
            Me.slecPicture.Text = Me.RightSLE3.Picture
            Me.PbFolderSLE1.Title = "Please Choose Folder"


            ' ********************************************
            ' * set up a days array for the holidays to  *
            ' * highlight                                *
            ' ********************************************
            oDays = New wmGUI.Days("11/11/2010", "Willie's Birthday") 'New wmGUI.Days("04/14/2008", "Willie was here")
            aHolidays.Add(oDays)
            Me.PbDateSLE1.Holiday = aHolidays

            ' ********************************************
            ' * build a datarange                        *
            ' ********************************************
            'oDateRange = New wmDateRange("05/01/2010", "05/07/2010")
            'Me.PbDateSLE1.DateRange = oDateRange

            ' set the combobox based on the Initial SLE value
            Select Case Me.RightSLE3.Type
                Case SLEType.Numeric
                    Me.cbType.Text = "Numeric"
                Case SLEType.Character
                    Me.cbType.Text = "Character"
                Case SLEType.Date
                    Me.cbType.Text = "Date"
                Case SLEType.Logic
                    Me.cbType.Text = "Logic"
                Case Else
                    Me.cbType.Text = "Character"
            End Select

        Catch ex As Exception
            MessageBox.Show(ex.ToString())
        End Try
    End Sub
    Public Sub onHolidayDateRightClick(ByVal oDlg As Object, ByVal dMouseDate As DateTime)
        MessageBox.Show(dMouseDate.ToString())
    End Sub
    Public Function onMonthYearMove(ByVal dNewDate As DateTime) As ArrayList
        Dim aResult As New ArrayList
        Dim nMonth As Long
        nMonth = Month(dNewDate)
        ' set the holiday's
        If nMonth = 1 Then
            aResult.Add(New wmGUI.Days("01/01/2010", "New Years", "50,204,153"))
        ElseIf nMonth = 11 Then
            'aResult.Add(New wmGUI.Days("11/11/2010", "Willie's Birthday"))
        End If
        onMonthYearMove = aResult
    End Function
    Public Sub sleSearch(ByVal oControl As Object, ByVal strText As String)
        oControl.Text = "Willie"
    End Sub
    Private Sub pbUpdateFS_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pbUpdateFS.Click
        ' Dim cCharToTest As String
        'Dim cText As String
        'Dim i As Long
        'Dim nStrLen As Long
        'Dim lNumeric As Boolean
        Dim cDataType As String

        ' set the datatype based on the combobox
        cDataType = Me.cbType.SelectedItem.ToString()
        Select Case cDataType
            Case "Numeric"
                Me.RightSLE3.Type = SLEType.Numeric
            Case "Character"
                Me.RightSLE3.Type = SLEType.Character
            Case "Date"
                Me.RightSLE3.Type = SLEType.Date
            Case "Logic"
                Me.RightSLE3.Type = SLEType.Logic
            Case Else
                Me.RightSLE3.Type = SLEType.Character
        End Select


        Me.RightSLE3.Picture = Me.slecPicture.Text

        ' look at the picture and it if contains non numeric, set the rightSLE to SLEType.Character
        'cText = Me.slecPicture.Text
        'nStrLen = cText.Length
        'lNumeric = True
        'For i = 0 To nStrLen - 1
        'cCharToTest = cText.Substring(i, 1)
        'If ("($, ".IndexOf(cCharToTest) < 0) Then
        'If Not (Char.IsDigit(cCharToTest, 0) Or cCharToTest = ".") Then
        'lNumeric = False
        'End If
        'End If
        'Next
        'If lNumeric Then
        'Me.RightSLE3.Type = SLEType.Numeric
        'Else
        'Me.RightSLE3.Type = SLEType.Character
        'End If
        'Me.RightSLE3.updateFieldspec(New gen_money())
    End Sub

    Private Sub rbHome_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbHome.CheckedChanged
        Me.rbgFocus = "H"
        wmGUI.rightSLE.DefaultSelectionOnFocus = focusBehavior.Home
    End Sub

    Private Sub rbAll_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbAll.CheckedChanged
        Me.rbgFocus = "A"
        wmGUI.rightSLE.DefaultSelectionOnFocus = focusBehavior.All
    End Sub

    Private Sub rbTrim_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbTrim.CheckedChanged
        Me.rbgFocus = "T"
        wmGUI.rightSLE.DefaultSelectionOnFocus = focusBehavior.Trimmed
    End Sub

    Private Sub rbEnd_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbEnd.CheckedChanged
        Me.rbgFocus = "E"
        wmGUI.rightSLE.DefaultSelectionOnFocus = focusBehavior.End
    End Sub

    Private Sub rbAuto_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbAuto.CheckedChanged
        Me.rbgFocus = "Auto"
        wmGUI.rightSLE.DefaultSelectionOnFocus = focusBehavior.Auto
    End Sub
    Private Sub rbRemember_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbRemember.CheckedChanged
        Me.rbgFocus = "R"
        wmGUI.rightSLE.DefaultSelectionOnFocus = focusBehavior.RememberLast
    End Sub

    Private Sub rbNumeric_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbNumeric.CheckedChanged
        Me.rbgFocus = "N"
        wmGUI.rightSLE.DefaultSelectionOnFocus = focusBehavior.Numeric
    End Sub

    Private Sub rbProcess_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbProcess.CheckedChanged
        Me.rbgEnter = "P"
        wmGUI.rightSLE.DefaultProcessEnter = KeyHandling.Process
    End Sub

    Private Sub rbIgnore_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbIgnore.CheckedChanged
        Me.rbgEnter = "I"
        wmGUI.rightSLE.DefaultProcessEnter = KeyHandling.Ignore
    End Sub

    Private Sub rbEnterAuto_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbEnterAuto.CheckedChanged
        Me.rbgEnter = "Auto"
        wmGUI.rightSLE.DefaultProcessEnter = KeyHandling.Auto
    End Sub

    Private Sub rbArrowAuto_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbArrowAuto.CheckedChanged
        Me.rbgArrow = "Auto"
        wmGUI.rightSLE.DefaultProcessArrow = KeyHandling.Auto
    End Sub

    Private Sub rbArrowIgnore_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbArrowIgnore.CheckedChanged
        Me.rbgArrow = "I"
        wmGUI.rightSLE.DefaultProcessArrow = KeyHandling.Ignore
    End Sub

    Private Sub rbArrowProcess_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbArrowProcess.CheckedChanged
        Me.rbgArrow = "P"
        wmGUI.rightSLE.DefaultProcessArrow = KeyHandling.Process
    End Sub

    Private Sub pbHide_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pbHide.Click
        If Me.PbDateSLE1.Visible Then
            Me.pbHide.Text = "Show"
            Me.PbDateSLE1.Visible = False
        Else
            Me.pbHide.Text = "Hide"
            Me.PbDateSLE1.Visible = True
        End If
    End Sub

    Private Sub pbEnable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pbEnable.Click
        If Me.PbDateSLE1.Enabled Then
            Me.pbEnable.Text = "Enable"
            Me.PbDateSLE1.Enabled = False
        Else
            Me.pbEnable.Text = "Disable"
            Me.PbDateSLE1.Enabled = True
        End If
    End Sub

    Private Sub pbFirstDayOfWeek_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pbFirstDayOfWeek.Click
        If Me.pbFirstDayOfWeek.Text = "Sunday" Then
            Me.pbFirstDayOfWeek.Text = "Monday"
            Me.PbDateSLE1.FirstDayoftheWeek = 2
        Else
            Me.pbFirstDayOfWeek.Text = "Sunday"
            Me.PbDateSLE1.FirstDayoftheWeek = 1
        End If

    End Sub

    Private Sub pbReadOnly_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pbReadOnly.Click
        If Me.PbDateSLE1.ReadOnly Then
            Me.PbDateSLE1.ReadOnly = False
        Else
            Me.PbDateSLE1.ReadOnly = True
        End If

    End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If Me.PbFileSLE1.Empty Then
            MessageBox.Show("fileSLE is Currently Empty")
        Else
            MessageBox.Show("fileSLE is NOT Empty")
        End If
    End Sub
End Class
